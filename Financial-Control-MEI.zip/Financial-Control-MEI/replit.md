# Controle MEI - Financial Control Application

## Overview

This is a financial control application designed for MEI (Microempreendedor Individual - Brazilian small business owners). The application allows users to track incomes and costs, view monthly summaries with charts, and export financial data to Excel spreadsheets. The UI is presented in Portuguese (Brazilian).

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript
- **Routing**: Wouter (lightweight React router)
- **State Management**: TanStack React Query for server state caching and synchronization
- **UI Components**: shadcn/ui component library built on Radix UI primitives
- **Styling**: Tailwind CSS with CSS variables for theming
- **Charts**: Recharts for data visualization (bar charts showing monthly income vs costs)
- **Forms**: React Hook Form with Zod validation
- **Build Tool**: Vite

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript (ES modules)
- **API Style**: RESTful endpoints under `/api/*`
- **Database ORM**: Drizzle ORM with PostgreSQL dialect
- **Validation**: Zod schemas shared between client and server

### Data Storage
- **Database**: PostgreSQL (required via DATABASE_URL environment variable)
- **Schema**: Two main tables - `incomes` and `costs`
  - Incomes track: date, description, amount charged, and associated costs (material, labor, gasoline, utilities)
  - Costs track: date, description, material cost, and labor cost
- **Migrations**: Drizzle Kit for schema management (`db:push` command)

### API Structure
The API is defined in `shared/routes.ts` with typed contracts:
- `GET/POST/DELETE /api/incomes` - CRUD for income records
- `GET/POST/DELETE /api/costs` - CRUD for cost records  
- `GET /api/summary` - Monthly aggregated statistics
- `GET /api/summary/download` - Excel export functionality

### Key Design Patterns
1. **Shared Types**: Schema and API types are shared between frontend and backend via the `@shared` path alias
2. **Type-safe API**: Zod schemas validate both input and output at API boundaries
3. **Component Architecture**: Reusable UI components with consistent styling through shadcn/ui
4. **Storage Abstraction**: `IStorage` interface in `server/storage.ts` abstracts database operations

## External Dependencies

### Database
- **PostgreSQL**: Primary data store, connection via `DATABASE_URL` environment variable
- **Drizzle ORM**: Schema definition and query building
- **connect-pg-simple**: PostgreSQL session store (available but sessions not currently implemented)

### Excel Export
- **ExcelJS**: Server-side Excel file generation for financial report downloads

### UI Libraries
- **Radix UI**: Accessible primitive components (dialogs, dropdowns, forms, etc.)
- **Recharts**: React charting library for financial visualizations
- **Lucide React**: Icon library
- **date-fns**: Date formatting with Portuguese (pt-BR) locale support

### Build & Development
- **Vite**: Frontend bundling and dev server with HMR
- **esbuild**: Server bundling for production
- **tsx**: TypeScript execution for development

### Replit-specific
- **@replit/vite-plugin-runtime-error-modal**: Error overlay in development
- **@replit/vite-plugin-cartographer**: Development tooling
- **@replit/vite-plugin-dev-banner**: Development banner